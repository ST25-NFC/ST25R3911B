/******************************************************************************
  * \attention
  *
  * <h2><center>&copy; COPYRIGHT 2019 STMicroelectronics</center></h2>
  *
  * Licensed under ST MYLIBERTY SOFTWARE LICENSE AGREEMENT (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        www.st.com/myliberty
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied,
  * AND SPECIFICALLY DISCLAIMING THE IMPLIED WARRANTIES OF MERCHANTABILITY,
  * FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
******************************************************************************/

/*! \file
 *
 *  \author 
 *
 *  \brief Demo application
 *
 *  This demo shows how to poll for several types of NFC cards/devices and how 
 *  to exchange data with these devices, using the RFAL library.
 *
 *  This demo does not fully implement the activities according to the standards,
 *  it performs the required to communicate with a card/device and retrieve 
 *  its UID. Also blocking methods are used for data exchange which may lead to
 *  long periods of blocking CPU/MCU.
 *  For standard compliant example please refer to the Examples provided
 *  with the RFAL library.
 * 
 */
 
/*
 ******************************************************************************
 * INCLUDES
 ******************************************************************************
 */
#include "demo.h"
#include "utils.h"
#include "rfal_nfc.h"
#include "rfal_st25xv.h"


/*
******************************************************************************
* GLOBAL DEFINES
******************************************************************************
*/

/* Definition of possible states the demo state machine could have */
#define DEMO_ST_NOTINIT               0     /*!< Demo State:  Not initialized        */
#define DEMO_ST_START_DISCOVERY       1     /*!< Demo State:  Start Discovery        */
#define DEMO_ST_DISCOVERY             2     /*!< Demo State:  Discovery              */

#define DEMO_NFCV_BLOCK_LEN           4     /*!< NFCV Block len                      */
#define RFAL_NFCV_CMD_GET_BLK_SECURITY_STATUS    0x2CU  /*!< Get System Information command                               */
#define DEMO_NFCV_USE_SELECT_MODE     false /*!< NFCV demonstrate select mode        */
#define DEMO_NFCV_WRITE_TAG           false /*!< NFCV demonstrate Write Single Block */
#define DEMO_NFCV_LOCK_BLOCK          true //CL/*!< NFCV demonstrate Lock Single Block */
	
#define ST25DV_GPO_REG                       0x00
/** @brief ST25DV IT duration register address. */
#define ST25DV_ITTIME_REG                    0x01
/** @brief ST25DV Energy Harvesting register address. */
#define ST25DV_EH_MODE_REG                   0x02
/** @brief ST25DV RF management register address. */
#define ST25DV_RF_MNGT_REG                   0x03
/** @brief ST25DV Area 1 security register address. */
#define ST25DV_RFA1SS_REG                    0x04
/** @brief ST25DV Area 1 end address register address. */
#define ST25DV_ENDA1_REG                      0x05
/** @brief ST25DV Area 2 security register address. */
#define ST25DV_RFA2SS_REG                    0x06
/** @brief ST25DV Area 2 end address register address. */
#define ST25DV_ENDA2_REG                      0x07
/** @brief ST25DV Area 3 security register address. */
#define ST25DV_RFA3SS_REG                    0x08
/** @brief ST25DV Area 3 end address register address. */
#define ST25DV_ENDA3_REG                      0x09
/** @brief ST25DV Area 4 security register address. */
#define ST25DV_RFA4SS_REG                    0x0A

/** @brief ST25DV Mailbox mode register address. */
#define ST25DV_MB_MODE_REG                   0x0D
/** @brief ST25DV Mailbox Watchdog register address. */
#define ST25DV_MB_WDG_REG                    0x0E
/** @brief ST25DV Configuration lock register address. */
#define ST25DV_LOCKCFG_REG                   0x0F
/** @brief ST25DV DSFID lock register address. */



/* MB_CTRL_Dyn */
#define ST25DV_MB_CTRL_DYN_MBEN_SHIFT        (0)
#define ST25DV_MB_CTRL_DYN_MBEN_FIELD        0xFE
#define ST25DV_MB_CTRL_DYN_MBEN_MASK         0x01
#define ST25DV_MB_CTRL_DYN_HOSTPUTMSG_SHIFT  (1)
#define ST25DV_MB_CTRL_DYN_HOSTPUTMSG_FIELD  0xFD
#define ST25DV_MB_CTRL_DYN_HOSTPUTMSG_MASK   0x02
#define ST25DV_MB_CTRL_DYN_RFPUTMSG_SHIFT    (2)
#define ST25DV_MB_CTRL_DYN_RFPUTMSG_FIELD    0xFB
#define ST25DV_MB_CTRL_DYN_RFPUTMSG_MASK     0x04
#define ST25DV_MB_CTRL_DYN_STRESERVED_SHIFT  (3)
#define ST25DV_MB_CTRL_DYN_STRESERVED_FIELD  0xF7
#define ST25DV_MB_CTRL_DYN_STRESERVED_MASK   0x08
#define ST25DV_MB_CTRL_DYN_HOSTMISSMSG_SHIFT (4)
#define ST25DV_MB_CTRL_DYN_HOSTMISSMSG_FIELD 0xEF
#define ST25DV_MB_CTRL_DYN_HOSTMISSMSG_MASK  0x10
#define ST25DV_MB_CTRL_DYN_RFMISSMSG_SHIFT   (5)
#define ST25DV_MB_CTRL_DYN_RFMISSMSG_FIELD   0xDF
#define ST25DV_MB_CTRL_DYN_RFMISSMSG_MASK    0x20
#define ST25DV_MB_CTRL_DYN_CURRENTMSG_SHIFT  (6)
#define ST25DV_MB_CTRL_DYN_CURRENTMSG_FIELD  0x3F
#define ST25DV_MB_CTRL_DYN_CURRENTMSG_MASK   0xC0

/* RFSS */
//ST25DV_RFA1SS_REG
#define ST25DV_RFSS_PZ_SHIFT              (2)
#define ST25DV_RFSS_PZ_MASK               0x0C

/*
 ******************************************************************************
 * GLOBAL MACROS
 ******************************************************************************
 */

/*
 ******************************************************************************
 * LOCAL VARIABLES
 ******************************************************************************

 */

/**
 * @brief  ST25DV Memory size structure definition.
 */
typedef struct
{
  uint8_t BlockSize;
  uint16_t MemSize;
} ST25DV_MEM_SIZE;
 
/**
 * @brief  ST25DV area end address enumerator definition.
 */
typedef enum
{
  ST25DV_ZONE_END1 = 0,
  ST25DV_ZONE_END2,
  ST25DV_ZONE_END3
} ST25DV_END_ZONE;

typedef enum
{
  ST25DV_ZONE1 = 0,
  ST25DV_ZONE2,
  ST25DV_ZONE3,
  ST25DV_ZONE4
} ST25DV_ZONE;

/*
 ******************************************************************************
 * LOCAL VARIABLES
 ******************************************************************************
 */
static rfalNfcDiscoverParam discParam;
static uint8_t              state = DEMO_ST_NOTINIT;

/*
******************************************************************************
* LOCAL FUNCTION PROTOTYPES
******************************************************************************
*/


static void demoNfcv( rfalNfcvListenDevice *nfcvDev );

static void demoNotif( rfalNfcState st );
ReturnCode  demoTransceiveBlocking( uint8_t *txBuf, uint16_t txBufSize, uint8_t **rxBuf, uint16_t **rcvLen, uint32_t fwt );
ReturnCode rfalNfcvPollerGetBlockSecurityStatus( uint8_t flags, const uint8_t* uid, uint8_t firstBlockNum, uint8_t numOfBlocks, uint8_t* rxBuf, uint16_t rxBufLen, uint16_t *rcvLen );
uint16_t ST25DV_ReadMemSize( uint8_t flags, const uint8_t* uid, ST25DV_MEM_SIZE * const pSizeInfo);
ReturnCode ST25DV_WriteEndZonex( uint8_t flags, const uint8_t* uid ,const ST25DV_END_ZONE EndZone, const uint8_t EndZ );
ReturnCode ST25DV_CreateUserZone( uint8_t flags, const uint8_t* uid, uint16_t Zone1Length, uint16_t Zone2Length, uint16_t Zone3Length, uint16_t Zone4Length );
int32_t ST25DV_InitEndZone( uint8_t flags, const uint8_t* uid );

static ReturnCode ST25DV_GetI2CSS_PZx( const uint8_t* uid, ST25DV_ZONE zonex, uint8_t *value);
static ReturnCode ST25DV_SetI2CSS_PZx( const uint8_t* uid, ST25DV_ZONE zonex, uint8_t value);

/*!
 *****************************************************************************
 * \brief Demo Notification
 *
 *  This function receives the event notifications from RFAL
 *****************************************************************************
 */
static void demoNotif( rfalNfcState st )
{
    uint8_t       devCnt;
    rfalNfcDevice *dev;
    
    
    if( st == RFAL_NFC_STATE_WAKEUP_MODE )
    {
        platformLog("Wake Up mode started \r\n");
    }
    else if( st == RFAL_NFC_STATE_POLL_TECHDETECT )
    {
        platformLog("Wake Up mode terminated. Polling for devices \r\n");
    }
    else if( st == RFAL_NFC_STATE_POLL_SELECT )
    {
        /* Multiple devices were found, activate first of them */
        rfalNfcGetDevicesFound( &dev, &devCnt );
        rfalNfcSelect( 0 );
        
        platformLog("Multiple Tags detected: %d \r\n", devCnt);
    }
}

/*!
 *****************************************************************************
 * \brief Demo Ini
 *
 *  This function Initializes the required layers for the demo
 *
 * \return true  : Initialization ok
 * \return false : Initialization failed
 *****************************************************************************
 */
bool demoIni( void )
{
    ReturnCode err;
    
    err = rfalNfcInitialize();
    if( err == ERR_NONE )
    {
        discParam.compMode      = RFAL_COMPLIANCE_MODE_NFC;
        discParam.devLimit      = 1U;


        discParam.notifyCb             = demoNotif;
        discParam.totalDuration        = 1000U;
        discParam.wakeupEnabled        = false;
        discParam.wakeupConfigDefault  = true;
        discParam.techs2Find           = (  RFAL_NFC_POLL_TECH_V );
        

	
        state = DEMO_ST_START_DISCOVERY;
        return true;
    }
    return false;
}

/*!
 *****************************************************************************
 * \brief Demo Cycle
 *
 *  This function executes the demo state machine. 
 *  It must be called periodically
 *****************************************************************************
 */
void demoCycle( void )
{
    static rfalNfcDevice *nfcDevice;
    
    rfalNfcWorker();                                    /* Run RFAL worker periodically */

    /*******************************************************************************/
    /* Check if USER button is pressed */
    if( platformGpioIsLow(PLATFORM_USER_BUTTON_PORT, PLATFORM_USER_BUTTON_PIN))
    {
        discParam.wakeupEnabled = !discParam.wakeupEnabled;    /* enable/disable wakeup */
        state = DEMO_ST_START_DISCOVERY;                       /* restart loop          */
        platformLog("Toggling Wake Up mode %s\r\n", discParam.wakeupEnabled ? "ON": "OFF");

        /* Debounce button */
        while( platformGpioIsLow(PLATFORM_USER_BUTTON_PORT, PLATFORM_USER_BUTTON_PIN) );
    }
  
    
    switch( state )
    {
        /*******************************************************************************/
        case DEMO_ST_START_DISCOVERY:

          platformLedOff(PLATFORM_LED_A_PORT, PLATFORM_LED_A_PIN);
          platformLedOff(PLATFORM_LED_B_PORT, PLATFORM_LED_B_PIN);
          platformLedOff(PLATFORM_LED_F_PORT, PLATFORM_LED_F_PIN);
          platformLedOff(PLATFORM_LED_V_PORT, PLATFORM_LED_V_PIN);
          platformLedOff(PLATFORM_LED_AP2P_PORT, PLATFORM_LED_AP2P_PIN);
          platformLedOff(PLATFORM_LED_FIELD_PORT, PLATFORM_LED_FIELD_PIN);
          
          rfalNfcDeactivate( false );
          rfalNfcDiscover( &discParam );
          
          state = DEMO_ST_DISCOVERY;
          break;

        /*******************************************************************************/
        case DEMO_ST_DISCOVERY:
        
            if( rfalNfcIsDevActivated( rfalNfcGetState() ) )
            {
                rfalNfcGetActiveDevice( &nfcDevice );
                
                switch( nfcDevice->type )
                {
                    /*******************************************************************************/

                    /*******************************************************************************/
          
                    
                    /*******************************************************************************/
                    case RFAL_NFC_LISTEN_TYPE_NFCV:
                        {
                            uint8_t devUID[RFAL_NFCV_UID_LEN];
                            
                            ST_MEMCPY( devUID, nfcDevice->nfcid, nfcDevice->nfcidLen );   /* Copy the UID into local var */
                            REVERSE_BYTES( devUID, RFAL_NFCV_UID_LEN );                 /* Reverse the UID for display purposes */
                            platformLog("ISO15693/NFC-V card found. UID: %s\r\n", hex2Str(devUID, RFAL_NFCV_UID_LEN));
                        
                            platformLedOn(PLATFORM_LED_V_PORT, PLATFORM_LED_V_PIN);
                            
                            demoNfcv( &nfcDevice->dev.nfcv );
                        }
                        break;
                        
          
                    
                    /*******************************************************************************/
                    default:
                        break;
                }
                
                rfalNfcDeactivate( false );
                platformDelay( 500 );
                state = DEMO_ST_START_DISCOVERY;
            }
            break;

        /*******************************************************************************/
        case DEMO_ST_NOTINIT:
        default:
            break;
    }
}


/*!
 *****************************************************************************
 * \brief Demo NFC-V Exchange
 *
 * Example how to exchange read and write blocks on a NFC-V tag
 * 
 *****************************************************************************
 */
static void demoNfcv( rfalNfcvListenDevice *nfcvDev )
{
    ReturnCode            err;
    uint8_t               value;
    uint8_t *             uid; 
	uint8_t 			  pwdNum=0; //Password Number (00h = Password configuration, 0x01 = Pswd1, 0x02 = Pswd2, 0x03 = Pswd3
	uint8_t 			  pwd[8]={0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}; //CL: for ST25DV, pwd is 8 bytes

    uid = nfcvDev->InvRes.UID;  

	/* You need to present password to change static configuration */		
    err = rfalST25xVPollerPresentPassword( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, pwdNum, pwd, sizeof(pwd)); //CL: before changing the static register, need to present firstly the PWD.
    if(err!=ERR_NONE)
    {
        platformLog("Error code %d!\r\n",err);
        return;
    }
    
    err = ST25DV_SetI2CSS_PZx( uid, ST25DV_ZONE4, 1);
    if(ERR_NONE == err) 
    {
       platformLog( "Set Area 4 RF write protected.\r\n" );
    }
			
    err = ST25DV_GetI2CSS_PZx( uid, ST25DV_ZONE4, &value);
    if(ERR_NONE == err) 
      {
        switch(value){
          case 0:
           platformLog( "Area 4 RF access: Read always allowed, Write always allowed.\r\n" );
          break;
          case 1:
           platformLog( "Area 4 RF access: Read always allowed, Write allowed if RF user security session is open.\r\n" );
          break;
          case 2:
           platformLog( "Area 4 RF access: Read allowed if RF user security session is open, Write allowed if RF user security session is open.\r\n" );
          break;
          case 3:
           platformLog( "Area 4 RF access: Read allowed if RF user security session is open, Write always forbidden.\r\n" );
          break;
          default:
            platformLog( "Value is out of range!\r\n" );
          break;
        }
    }
}

/*! 
 *****************************************************************************
 * \brief  NFC-V Get Multiple Block Security Status request format
 *  
 * Sends Get Multiple Block Security Status request command  
 *
 * \param[in]  flags          : Flags to be used: Sub-carrier; Data_rate; Option
 *                              for NFC-Forum use: RFAL_NFCV_REQ_FLAG_DEFAULT
 * \param[in]  uid            : UID of the device to be put to be read
 *                               if not provided Select mode will be used 
 * \param[in]  requestField   : Get System info parameter request field
 * \param[out] rxBuf          : buffer to store response (also with RES_FLAGS)
 * \param[in]  rxBufLen       : length of rxBuf
 * \param[out] rcvLen         : number of bytes received
 *  
 * \return ERR_WRONG_STATE    : RFAL not initialized or incorrect mode
 * \return ERR_PARAM          : Invalid parameters
 * \return ERR_IO             : Generic internal error 
 * \return ERR_CRC            : CRC error detected
 * \return ERR_FRAMING        : Framing error detected
 * \return ERR_PROTO          : Protocol error detected
 * \return ERR_TIMEOUT        : Timeout error
 * \return ERR_NONE           : No error
 *****************************************************************************
 */
ReturnCode rfalNfcvPollerGetBlockSecurityStatus( uint8_t flags, const uint8_t* uid, uint8_t firstBlockNum, uint8_t numOfBlocks, uint8_t* rxBuf, uint16_t rxBufLen, uint16_t *rcvLen )
{
    uint8_t            data[(RFAL_NFCV_BLOCKNUM_LEN + RFAL_NFCV_BLOCKNUM_LEN)];
    uint8_t            dataLen;
    
    dataLen = 0U;
    
    /* Compute Request Data */
    data[dataLen++] = firstBlockNum;                    /* Set first Block Number       */
    data[dataLen++] = numOfBlocks;                      /* Set number of blocks to read */
    
    return rfalNfcvPollerTransceiveReq( RFAL_NFCV_CMD_GET_BLK_SECURITY_STATUS, flags, RFAL_NFCV_PARAM_SKIP, uid, data, dataLen, rxBuf, rxBufLen, rcvLen );
}



uint16_t ST25DV_ReadMemSize( uint8_t flags, const uint8_t* uid, ST25DV_MEM_SIZE * const pSizeInfo)
{

 //   uint8_t               BlockBytes;		//CL: Number of bytes in each block;
    ReturnCode            err;
    uint8_t               rxBuf[17]; 
		uint16_t 							rcvLen;
//		uint16_t 							Mem_size ;
  /* Read actual value of MEM_SIZE register */
	
		err = rfalNfcvPollerGetSystemInformation( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, rxBuf, sizeof(rxBuf), &rcvLen );
	  if( err == ERR_NONE )
    {
		
	//	platformLog("Error code %d!;rcvLen: %d \r\n",err,rcvLen);
//		platformLog(" Get system infomation: %s %s\r\n", (err != ERR_NONE) ? "FAIL": "OK Data:", (err != ERR_NONE) ? "" : hex2Str( &rxBuf[0], rcvLen+2));

  /* st25dvmemsize is composed of BlockSize (number of blocks) and BlockBytes(size of each blocks in bytes) */		
			pSizeInfo->BlockSize = rxBuf[13]; //size of each blocks in bytes
			pSizeInfo->MemSize = rxBuf[12]; //(number of blocks) 
//			Mem_size = (pSizeInfo->BlockSize +1)*(BlockBytes+1)*8;//CL: Mem_size= (Block_size+1)*(Block_Num+1)*4Bytes*8Bits
//			return Mem_size;
		}
		return ERR_NONE;
}

/**
  * @brief    Sets the end address of an area.
  * @details  Needs the I2C Password presentation to be effective.
  * @note     The ST25DV answers a NACK when setting the EndZone2 & EndZone3 to same value than repectively EndZone1 & EndZone2.\n
  *           These NACKs are ok.
  * @param  EndZone ST25DV_END_ZONE value corresponding to an area.
  * @param  EndZ   End zone value to be written.
  * @return int32_t enum status.
  */
ReturnCode ST25DV_WriteEndZonex( uint8_t flags, const uint8_t* uid ,const ST25DV_END_ZONE EndZone, const uint8_t EndZ )
{
  ReturnCode status;
  
  /* Write the corresponding End zone value in register */  
  switch( EndZone )
  {
    case ST25DV_ZONE_END1:
     // status = ST25DV_SetENDA1(&(pObj->Ctx),&EndZ);
			status = rfalST25xVPollerWriteConfiguration( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, ST25DV_ENDA1_REG, EndZ );
      break;
    case ST25DV_ZONE_END2:
     // status = ST25DV_SetENDA2(&(pObj->Ctx),&EndZ);
			status = rfalST25xVPollerWriteConfiguration( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, ST25DV_ENDA2_REG, EndZ );
      break;
    case ST25DV_ZONE_END3:
    //  status = ST25DV_SetENDA3(&(pObj->Ctx),&EndZ);
			status = rfalST25xVPollerWriteConfiguration( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, ST25DV_ENDA3_REG, EndZ );
      break;
    
    default:
      return ERR_NONE;
  }

  return status;
}

/**
  * @brief  Initializes the end address of the ST25DV areas with their default values (end of memory).
  * @details  Needs the I2C Password presentation to be effective..
  *           The ST25DV answers a NACK when setting the EndZone2 & EndZone3 to same value than repectively EndZone1 & EndZone2.
  *           These NACKs are ok.
  * @return int32_t enum status.
  */
int32_t ST25DV_InitEndZone( uint8_t flags, const uint8_t* uid )
{
  uint8_t endval = 0xFF;
  uint32_t maxmemlength;
  ST25DV_MEM_SIZE memsize;
  int32_t ret;
  
  memsize.MemSize = 0;
  memsize.BlockSize = 0;

  /* Get EEPROM mem size */
  maxmemlength = ST25DV_ReadMemSize(flags,uid,&memsize);
  
  /* Compute Max value for endzone register */
  endval = (maxmemlength / 32 / 8) - 1;//32 Bytes minimum   
  /* Write EndZone value to ST25DV registers */

  ret = ST25DV_WriteEndZonex(flags, uid, ST25DV_ZONE_END3, endval );
  if(ret != ERR_NONE)
  {
    return ret;
  }

  ret = ST25DV_WriteEndZonex(flags, uid, ST25DV_ZONE_END2, endval );
  if(ret != ERR_NONE)
  {
    return ret;
  }

  ret = ST25DV_WriteEndZonex(flags, uid,  ST25DV_ZONE_END1, endval );
  if(ret != ERR_NONE)
  {
    return ret;
  }
  
  return ret;
}

/**
  * @brief  Creates user areas with defined lengths.
  * @details  Needs the I2C Password presentation to be effective.
  * @param  Zone1Length Length of area1 in bytes (32 to 8192, 0x20 to 0x2000)
  * @param  Zone2Length Length of area2 in bytes (0 to 8128, 0x00 to 0x1FC0)
  * @param  Zone3Length Length of area3 in bytes (0 to 8064, 0x00 to 0x1F80)
  * @param  Zone4Length Length of area4 in bytes (0 to 8000, 0x00 to 0x1F40)
  * @return int32_t enum status.
  */

ReturnCode ST25DV_CreateUserZone( uint8_t flags, const uint8_t* uid, uint16_t Zone1Length, uint16_t Zone2Length, uint16_t Zone3Length, uint16_t Zone4Length )
{
  uint8_t EndVal;
  ST25DV_MEM_SIZE memsize;
  uint16_t maxmemlength = 0;
  int32_t ret;
  
  memsize.MemSize = 0;
  memsize.BlockSize = 0;

  //ST25DV_ReadMemSize(pObj, &memsize );
  ST25DV_ReadMemSize( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, &memsize);
  maxmemlength = (memsize.MemSize + 1) * (memsize.BlockSize + 1); //B
  
  /* Checks that values of different zones are in bounds */
  if( ( Zone1Length < 8 ) || ( Zone1Length > maxmemlength ) || ( Zone2Length > (maxmemlength - 8) ) 
      || ( Zone3Length > (maxmemlength - 16) ) || ( Zone4Length > (maxmemlength - 24) ) )
  {
    return ERR_NONE;
  }

  /* Checks that the total is less than the authorised maximum */
  if( ( Zone1Length + Zone2Length + Zone3Length + Zone4Length ) > maxmemlength )
  {
    return ERR_NONE;
  }
  
  /* if The value for each Length is not a multiple of 8 correct it. */
  if( (Zone1Length % 8) != 0 )
  {
    Zone1Length = Zone1Length - ( Zone1Length % 8 );
  }
  
  if( (Zone2Length % 8) != 0 )
  {
    Zone2Length = Zone2Length - ( Zone2Length % 8 );
  }
  
  if( (Zone3Length % 8) != 0 )
  {
    Zone3Length = Zone3Length - ( Zone3Length % 8 );
  }
  
  /* First right 0xFF in each Endx value */
//  ret = ST25DV_InitEndZone(flags,uid);
//			platformLog( "\n\r\n\rTEST3 code: %d!\n",ret);
  if(ret != ERR_NONE) 
  {
    return ret;
  }
  
  /* Then Write corresponding value for each zone */
  EndVal = (uint8_t)( (Zone1Length / 8 ) - 1 );
  ret = ST25DV_WriteEndZonex(flags, uid, ST25DV_ZONE_END1, EndVal );
  if(ret != ERR_NONE) 
  {
    return ret;
  }
  
  EndVal = (uint8_t)( ((Zone1Length + Zone2Length) / 8 ) - 1 );
  ret = ST25DV_WriteEndZonex(flags, uid, ST25DV_ZONE_END2, EndVal );
  if(ret != ERR_NONE) 
  {
    return ret;
  }
  
  EndVal = (uint8_t)( ((Zone1Length + Zone2Length + Zone3Length)  / 8  ) - 1 );
  ret = ST25DV_WriteEndZonex(flags, uid, ST25DV_ZONE_END3, EndVal );
  if(ret != ERR_NONE) 
  {
    return ret;
  }
  
  return ERR_NONE;
}

static ReturnCode ST25DV_GetI2CSS_PZx( const uint8_t* uid, ST25DV_ZONE zonex, uint8_t *value)
{
  ReturnCode err;
  
  /* Write the corresponding End zone value in register */  
  switch( zonex )
  {
    case ST25DV_ZONE1:
			err = rfalST25xVPollerReadConfiguration( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, ST25DV_RFA1SS_REG, value );
			if (err!=ERR_NONE)	return err;
			*value &= (ST25DV_RFSS_PZ_MASK);
			*value = *value >> (ST25DV_RFSS_PZ_SHIFT);
      break;			
    case ST25DV_ZONE2:
			err = rfalST25xVPollerReadConfiguration( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, ST25DV_RFA2SS_REG, value );
			if (err!=ERR_NONE)	return err;
			*value &= (ST25DV_RFSS_PZ_MASK);
			*value = *value >> (ST25DV_RFSS_PZ_SHIFT);
      break;			
    case ST25DV_ZONE3:
			err = rfalST25xVPollerReadConfiguration( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, ST25DV_RFA3SS_REG, value );
			if (err!=ERR_NONE)	return err;
			*value &= (ST25DV_RFSS_PZ_MASK);
			*value = *value >> (ST25DV_RFSS_PZ_SHIFT);
      break;
    case ST25DV_ZONE4:
			err = rfalST25xVPollerReadConfiguration( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, ST25DV_RFA4SS_REG, value );
			if (err!=ERR_NONE)	return err;
			*value &= (ST25DV_RFSS_PZ_MASK);
			*value = *value >> (ST25DV_RFSS_PZ_SHIFT);
      break;
    default:
      return ERR_NONE;
  }
  return err;
}

static ReturnCode ST25DV_SetI2CSS_PZx( const uint8_t* uid, ST25DV_ZONE zonex, uint8_t value)
{
  ReturnCode err;
  uint8_t reg_value;  
  /* Write the corresponding RFAxSS value in register */  
  switch( zonex )
  {
    case ST25DV_ZONE1:
			err = rfalST25xVPollerReadConfiguration( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, ST25DV_RFA1SS_REG, &reg_value );
			if (err!=ERR_NONE) return err;
			reg_value = ( (value << (ST25DV_RFSS_PZ_SHIFT)) & (ST25DV_RFSS_PZ_MASK)) |
                (reg_value & ~(ST25DV_RFSS_PZ_MASK));
			err = rfalST25xVPollerWriteConfiguration( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, ST25DV_RFA1SS_REG, reg_value );
      break;			
    case ST25DV_ZONE2:
			err = rfalST25xVPollerReadConfiguration( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, ST25DV_RFA2SS_REG, &reg_value );
			if (err!=ERR_NONE) return err;
			reg_value = ( (value << (ST25DV_RFSS_PZ_SHIFT)) & (ST25DV_RFSS_PZ_MASK)) |
                (reg_value & ~(ST25DV_RFSS_PZ_MASK));
			err = rfalST25xVPollerWriteConfiguration( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, ST25DV_RFA2SS_REG, reg_value );
      break;			
    case ST25DV_ZONE3:
			err = rfalST25xVPollerReadConfiguration( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, ST25DV_RFA3SS_REG, &reg_value );
			if (err!=ERR_NONE) return err;
			reg_value = ( (value << (ST25DV_RFSS_PZ_SHIFT)) & (ST25DV_RFSS_PZ_MASK)) |
                (reg_value & ~(ST25DV_RFSS_PZ_MASK));
			err = rfalST25xVPollerWriteConfiguration( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, ST25DV_RFA3SS_REG, reg_value );
      break;    
      case ST25DV_ZONE4:
			err = rfalST25xVPollerReadConfiguration( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, ST25DV_RFA4SS_REG, &reg_value );
			if (err!=ERR_NONE)	return err;
			reg_value = ( (value << (ST25DV_RFSS_PZ_SHIFT)) & (ST25DV_RFSS_PZ_MASK)) |
                (reg_value & ~(ST25DV_RFSS_PZ_MASK));
			err = rfalST25xVPollerWriteConfiguration( RFAL_NFCV_REQ_FLAG_DEFAULT, uid, ST25DV_RFA4SS_REG, reg_value );
      break;
    default:
      return ERR_NONE;
  }
  return err;
}


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
