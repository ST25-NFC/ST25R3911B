This example only supports TypeV communication. It allows to reader to Lock block of TypeV tag. 

this example code is based on en X-CUBE-NFC5.zip(STM32CubeExpansion_NFC5_V2.0.0), IDE used is Keil V5.

To execute the example code, please follow the following procedure:

1. Please download the sourecode on the ST website(ST account needed):
https://www.st.com/content/st_com/en/products/embedded-software/mcu-mpu-embedded-software/stm32-embedded-software/stm32cube-expansion-packages/x-cube-nfc5.html

2. Unzip the folder to get STM32CubeExpansion_NFC5_V2.0.0 original version

3. Unzip the example code and copied it to the example folder(eg..\...\STM32CubeExpansion_NFC5_V2.0.0\Projects\STM32L476RG-Nucleo\Examples\xxxx)

4. Rebuild ALL the project and enjoy!